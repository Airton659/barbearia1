import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';
import '../models/usuario.dart';
import '../models/servico.dart';
import '../models/agendamento.dart';
import '../models/horario_trabalho.dart';

class ApiService {
  static const String baseUrl = "https://barbearia-backend-service-862082955632.southamerica-east1.run.app";
  static const String negocioId = "YXcwY5rHdXBNRm4BtsP1"; // ID do negócio para multi-tenant
  
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Headers padrão com autenticação
  Future<Map<String, String>> _getHeaders() async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('Usuário não autenticado');
    
    final token = await user.getIdToken();
    
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
      'negocio-id': negocioId,
    };
  }

  // Método genérico para requisições GET
  Future<Map<String, dynamic>> _get(String endpoint) async {
    final headers = await _getHeaders();
    final response = await http.get(
      Uri.parse('$baseUrl$endpoint'),
      headers: headers,
    );
    
    return _handleResponse(response);
  }

  // Método genérico para requisições POST
  Future<Map<String, dynamic>> _post(String endpoint, Map<String, dynamic> data) async {
    final headers = await _getHeaders();
    final response = await http.post(
      Uri.parse('$baseUrl$endpoint'),
      headers: headers,
      body: jsonEncode(data),
    );
    
    return _handleResponse(response);
  }

  // Método genérico para requisições PUT
  Future<Map<String, dynamic>> _put(String endpoint, Map<String, dynamic> data) async {
    final headers = await _getHeaders();
    final response = await http.put(
      Uri.parse('$baseUrl$endpoint'),
      headers: headers,
      body: jsonEncode(data),
    );
    
    return _handleResponse(response);
  }

  // Método genérico para requisições DELETE
  Future<Map<String, dynamic>> _delete(String endpoint) async {
    final headers = await _getHeaders();
    final response = await http.delete(
      Uri.parse('$baseUrl$endpoint'),
      headers: headers,
    );
    
    return _handleResponse(response);
  }

  // Manipular resposta da API
  Map<String, dynamic> _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Erro na API: ${response.statusCode} - ${response.body}');
    }
  }

  // AUTENTICAÇÃO
  Future<Usuario> syncProfile() async {
    final data = await _post('/users/sync-profile', {});
    return Usuario.fromJson(data);
  }

  // VALIDAÇÃO DE CÓDIGO DE CONVITE
  Future<Usuario> validarCodigoConvite(String codigo) async {
    final data = {
      'codigo_convite': codigo,
    };
    
    // Primeiro sincronizar o perfil com o código de convite
    final result = await _post('/users/sync-profile', data);
    return Usuario.fromJson(result);
  }

  // VERIFICAR SE USUÁRIO PRECISA DE CÓDIGO DE CONVITE
  Future<bool> verificarNecessidadeCodigoConvite() async {
    try {
      final data = await _get('/negocios/$negocioId/admin-status');
      return !(data['tem_admin'] ?? true);
    } catch (e) {
      // Se erro, assumir que precisa de código
      return true;
    }
  }

  Future<Usuario> getProfile() async {
    final data = await _get('/me/profile');
    return Usuario.fromJson(data);
  }

  // PROFISSIONAIS
  Future<List<Usuario>> getProfissionais() async {
    final data = await _get('/profissionais');
    return (data['profissionais'] as List).map((json) => Usuario.fromJson(json)).toList();
  }

  Future<Usuario> getProfissional(String id) async {
    final data = await _get('/profissionais/$id');
    return Usuario.fromJson(data);
  }

  Future<Usuario> updateProfissionalProfile(Map<String, dynamic> profileData) async {
    final data = await _put('/me/profissional', profileData);
    return Usuario.fromJson(data);
  }

  // SERVIÇOS
  Future<List<Servico>> getServicos() async {
    final data = await _get('/servicos');
    return (data['servicos'] as List).map((json) => Servico.fromJson(json)).toList();
  }

  Future<List<Servico>> getMeusServicos() async {
    final data = await _get('/me/servicos');
    return (data['servicos'] as List).map((json) => Servico.fromJson(json)).toList();
  }

  Future<Servico> createServico(Map<String, dynamic> servicoData) async {
    final data = await _post('/me/servicos', servicoData);
    return Servico.fromJson(data);
  }

  Future<Servico> updateServico(String servicoId, Map<String, dynamic> servicoData) async {
    final data = await _put('/me/servicos/$servicoId', servicoData);
    return Servico.fromJson(data);
  }

  Future<void> deleteServico(String servicoId) async {
    await _delete('/me/servicos/$servicoId');
  }

  // HORÁRIOS DE TRABALHO
  Future<List<HorarioTrabalho>> getHorariosTrabalho() async {
    final data = await _get('/me/horarios-trabalho');
    return (data['horarios'] as List).map((json) => HorarioTrabalho.fromJson(json)).toList();
  }

  Future<List<HorarioTrabalho>> setHorariosTrabalho(List<Map<String, dynamic>> horarios) async {
    final data = await _post('/me/horarios-trabalho', {'horarios': horarios});
    return (data['horarios'] as List).map((json) => HorarioTrabalho.fromJson(json)).toList();
  }

  // HORÁRIOS DISPONÍVEIS
  Future<List<DateTime>> getHorariosDisponiveis(String profissionalId, String servicoId, DateTime data) async {
    final dataFormatada = data.toIso8601String().split('T')[0];
    final endpoint = '/profissionais/$profissionalId/horarios-disponiveis?servico_id=$servicoId&data=$dataFormatada';
    
    final response = await _get(endpoint);
    return (response['horarios_disponiveis'] as List)
        .map((horario) => DateTime.parse(horario))
        .toList();
  }

  // AGENDAMENTOS
  Future<Agendamento> createAgendamento(Map<String, dynamic> agendamentoData) async {
    final data = await _post('/agendamentos', agendamentoData);
    return Agendamento.fromJson(data);
  }

  Future<List<Agendamento>> getMeusAgendamentos() async {
    final data = await _get('/agendamentos/me');
    return (data['agendamentos'] as List).map((json) => Agendamento.fromJson(json)).toList();
  }

  Future<List<Agendamento>> getAgendamentosProfissional() async {
    final data = await _get('/me/agendamentos');
    return (data['agendamentos'] as List).map((json) => Agendamento.fromJson(json)).toList();
  }

  Future<void> cancelarAgendamento(String agendamentoId) async {
    await _delete('/agendamentos/$agendamentoId');
  }

  Future<void> cancelarAgendamentoProfissional(String agendamentoId) async {
    await _post('/me/agendamentos/$agendamentoId/cancelar', {});
  }

  // UPLOAD DE FOTO
  Future<String> uploadFoto(File imageFile) async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('Usuário não autenticado');
    
    final token = await user.getIdToken();
    
    var request = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/upload-foto'),
    );
    
    request.headers['Authorization'] = 'Bearer $token';
    request.headers['negocio-id'] = negocioId;
    
    request.files.add(await http.MultipartFile.fromPath('file', imageFile.path));
    
    var response = await request.send();
    var responseData = await response.stream.transform(utf8.decoder).join();
    
    if (response.statusCode >= 200 && response.statusCode < 300) {
      final data = jsonDecode(responseData);
      return data['foto_url'];
    } else {
      throw Exception('Erro ao fazer upload: $responseData');
    }
  }

  // === NOVA FUNÇÃO CORRIGIDA ===
  Future<Usuario> adminCreateUser(Map<String, dynamic> userData) async {
    // Endpoint correto conforme o README.md para criar um novo usuário via admin.
    final data = await _post('/negocios/$negocioId/pacientes', userData);
    return Usuario.fromJson(data);
  }
}