import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/client_home_screen.dart';
import 'screens/codigo_convite_screen.dart';
import 'screens/demo_login_screen.dart';
import 'services/api_service.dart';
import 'utils/app_colors.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  try {
    // Verificar se Firebase já foi inicializado
    if (Firebase.apps.isEmpty) {
      // Inicializar Firebase apenas se não existir ainda
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
      print('✅ Firebase inicializado com sucesso!');
    } else {
      print('✅ Firebase já estava inicializado!');
    }
  } catch (e) {
    // Se erro não for de app duplicado, mostrar instruções
    if (!e.toString().contains('duplicate-app')) {
      print('⚠️ ERRO FIREBASE: $e');
      print('📋 INSTRUÇÕES ANDROID:');
      print('1. Acesse https://console.firebase.google.com');
      print('2. Abra o projeto "teste-notificacao-barbearia"');
      print('3. Project Settings > Add app > Android');
      print('4. Package name: com.ygg.barbearia1');
      print('5. Baixe google-services.json');
      print('6. Coloque em: android/app/google-services.json');
      print('7. Authentication > Email/Password > Enable');
      print('8. Crie usuário: admin@com.br / 123456');
      print('');
      print('🔄 Continuando sem Firebase (use código de convite)...');
    } else {
      // App já existe, tudo ok
      print('✅ Firebase já configurado (app existia)!');
    }
  }
  
  // Inicializar localização em português
  await initializeDateFormatting('pt_BR', null);
  
  // Configurar orientação da tela
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  runApp(const BarbeariaApp());
}

class BarbeariaApp extends StatelessWidget {
  const BarbeariaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Barbearia',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.brown,
        primaryColor: AppColors.primary,
        scaffoldBackgroundColor: AppColors.background,
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: AppColors.primary),
          ),
        ),
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primary,
          brightness: Brightness.light,
        ),
      ),
      home: Firebase.apps.isNotEmpty ? const AuthWrapper() : const DemoLoginScreen(),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        if (snapshot.hasData) {
          // Usuário logado, verificar tipo
          return const UserRoleChecker();
        } else {
          // Usuário não logado
          return const LoginScreen();
        }
      },
    );
  }
}

class UserRoleChecker extends StatefulWidget {
  const UserRoleChecker({super.key});

  @override
  State<UserRoleChecker> createState() => _UserRoleCheckerState();
}

class _UserRoleCheckerState extends State<UserRoleChecker> {
  final ApiService _apiService = ApiService();

  @override
  void initState() {
    super.initState();
    _checkUserRole();
  }

  Future<void> _checkUserRole() async {
    try {
      // Primeiro, verificar se precisa de código de convite
      final precisaCodigoConvite = await _apiService.verificarNecessidadeCodigoConvite();
      
      if (precisaCodigoConvite && mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => const CodigoConviteScreen()),
        );
        return;
      }
      
      // Se não precisa de código, verificar perfil normalmente
      final usuario = await _apiService.getProfile();
      
      if (mounted) {
        if (usuario.role == 'admin' || usuario.role == 'profissional') {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => const DashboardScreen()),
          );
        } else {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => const ClientHomeScreen()),
          );
        }
      }
    } catch (e) {
      // ===================================================================
      // LINHA ADICIONADA PARA DEBUG
      // PROCURE POR ESTA MENSAGEM NO SEU CONSOLE APÓS TENTAR LOGAR
      print('### ERRO AO VERIFICAR PERFIL (API Backend): $e');
      // ===================================================================

      if (mounted) {
        // Erro ao verificar perfil, fazer logout
        await FirebaseAuth.instance.signOut();
        if (mounted) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => const LoginScreen()),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Carregando...'),
          ],
        ),
      ),
    );
  }
}