import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/usuario.dart';
import '../utils/app_colors.dart';
import 'user_create_screen.dart'; // IMPORTA A NOVA TELA

class ProfissionaisScreen extends StatefulWidget {
  const ProfissionaisScreen({super.key});

  @override
  State<ProfissionaisScreen> createState() => _ProfissionaisScreenState();
}

class _ProfissionaisScreenState extends State<ProfissionaisScreen> {
  final ApiService _apiService = ApiService();
  List<Usuario> _profissionais = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _carregarProfissionais();
  }

  Future<void> _carregarProfissionais() async {
    try {
      final profissionais = await _apiService.getProfissionais();
      setState(() {
        _profissionais = profissionais;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao carregar profissionais: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profissionais'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            // === onPressed CORRIGIDO ===
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const UserCreateScreen()),
              ).then((success) {
                // Se o usuário foi criado com sucesso (retornou true), atualiza a lista
                if (success == true) {
                  _carregarProfissionais();
                }
              });
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _carregarProfissionais,
              child: _profissionais.isEmpty
                  ? _buildEmptyState() // Usa o método _buildEmptyState com o botão corrigido
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: _profissionais.length,
                      itemBuilder: (context, index) {
                        final profissional = _profissionais[index];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundImage: profissional.fotoPerfil != null
                                  ? NetworkImage(profissional.fotoPerfil!)
                                  : null,
                              backgroundColor: AppColors.primary.withOpacity(0.1),
                              child: profissional.fotoPerfil == null
                                  ? const Icon(Icons.person, color: AppColors.primary)
                                  : null,
                            ),
                            title: Text(
                              profissional.nome,
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(profissional.email),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: profissional.ativo
                                            ? AppColors.success.withOpacity(0.1)
                                            : AppColors.error.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        profissional.ativo ? 'Ativo' : 'Inativo',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: profissional.ativo
                                              ? AppColors.success
                                              : AppColors.error,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: AppColors.info.withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        profissional.role.toUpperCase(),
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: AppColors.info,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            trailing: PopupMenuButton(
                              itemBuilder: (context) => [
                                const PopupMenuItem(
                                  value: 'edit',
                                  child: ListTile(
                                    leading: Icon(Icons.edit),
                                    title: Text('Editar'),
                                    contentPadding: EdgeInsets.zero,
                                  ),
                                ),
                                const PopupMenuItem(
                                  value: 'services',
                                  child: ListTile(
                                    leading: Icon(Icons.room_service),
                                    title: Text('Serviços'),
                                    contentPadding: EdgeInsets.zero,
                                  ),
                                ),
                                const PopupMenuItem(
                                  value: 'schedule',
                                  child: ListTile(
                                    leading: Icon(Icons.schedule),
                                    title: Text('Horários'),
                                    contentPadding: EdgeInsets.zero,
                                  ),
                                ),
                                PopupMenuItem(
                                  value: profissional.ativo ? 'deactivate' : 'activate',
                                  child: ListTile(
                                    leading: Icon(
                                      profissional.ativo ? Icons.block : Icons.check_circle,
                                      color: profissional.ativo ? AppColors.error : AppColors.success,
                                    ),
                                    title: Text(profissional.ativo ? 'Desativar' : 'Ativar'),
                                    contentPadding: EdgeInsets.zero,
                                  ),
                                ),
                              ],
                              onSelected: (value) {
                                switch (value) {
                                  case 'edit':
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Edição em desenvolvimento')),
                                    );
                                    break;
                                  case 'services':
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Gestão de serviços em desenvolvimento')),
                                    );
                                    break;
                                  case 'schedule':
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Gestão de horários em desenvolvimento')),
                                    );
                                    break;
                                  case 'activate':
                                  case 'deactivate':
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Alteração de status em desenvolvimento')),
                                    );
                                    break;
                                }
                              },
                            ),
                          ),
                        );
                      },
                    ),
            ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.people_outline,
            size: 64,
            color: AppColors.textLight,
          ),
          const SizedBox(height: 16),
          const Text(
            'Nenhum profissional encontrado',
            style: TextStyle(
              fontSize: 18,
              color: AppColors.textMedium,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Cadastre o primeiro profissional para começar',
            style: TextStyle(color: AppColors.textLight),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            // === onPressed CORRIGIDO TAMBÉM NO ESTADO VAZIO ===
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const UserCreateScreen()),
              ).then((success) {
                if (success == true) {
                  _carregarProfissionais();
                }
              });
            },
            icon: const Icon(Icons.add),
            label: const Text('Adicionar Profissional'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}