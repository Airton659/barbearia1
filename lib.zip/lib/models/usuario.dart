class Usuario {
  final String id;
  final String firebaseUid;
  final String nome;
  final String email;
  final String? telefone;
  final String? fotoPerfil;
  final String role;
  final bool ativo;
  final DateTime createdAt;
  final DateTime updatedAt;

  Usuario({
    required this.id,
    required this.firebaseUid,
    required this.nome,
    required this.email,
    this.telefone,
    this.fotoPerfil,
    required this.role,
    required this.ativo,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Usuario.fromJson(Map<String, dynamic> json) {
    return Usuario(
      id: json['id'],
      firebaseUid: json['firebase_uid'],
      nome: json['nome'],
      email: json['email'],
      telefone: json['telefone'],
      fotoPerfil: json['foto_perfil'],
      role: json['role'],
      ativo: json['ativo'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'firebase_uid': firebaseUid,
      'nome': nome,
      'email': email,
      'telefone': telefone,
      'foto_perfil': fotoPerfil,
      'role': role,
      'ativo': ativo,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }
}